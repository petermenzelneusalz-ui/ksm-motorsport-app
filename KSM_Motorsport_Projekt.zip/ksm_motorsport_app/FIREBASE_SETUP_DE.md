# KSM Motorsport – Online-Backend einrichten

Diese Dateien sind das vorbereitete Sicherheits-/Backend-Gerüst. Sie schalten die bestehende Android-Demo **noch nicht automatisch online**. Dazu muss ein Firebase-Projekt angelegt und die Android-App mit dessen Konfiguration und den Cloud-Funktionen verbunden werden.

## Benötigt
- Ein Google-Konto mit Zugriff auf Firebase Console
- Ein Firebase-Projekt für KSM Motorsport
- Firebase Authentication (E-Mail/Passwort oder E-Mail-Link)
- Cloud Firestore
- Firebase Cloud Functions (für E-Mail-Einladungen); je nach Region/Plan kann ein kostenpflichtiger Blaze-Plan erforderlich sein
- SMTP-Zugangsdaten eines E-Mail-Anbieters und eine HTTPS-Webseite für die Einladung annehmen

## Einrichtung
1. In Firebase Console ein Projekt `KSM Motorsport` erstellen.
2. Android-App registrieren mit Paketname `de.ksmmotorsport.app`.
3. Die von Firebase heruntergeladene `google-services.json` in `app/` ablegen.
4. In Authentication den gewünschten E-Mail-Anmeldeanbieter aktivieren.
5. Firestore-Datenbank erstellen und `firestore.rules` deployen.
6. Firebase CLI installieren und anmelden; im Ordner `firebase/` das Projekt mit `firebase use --add` auswählen.
7. Secrets setzen: `firebase functions:secrets:set SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `INVITE_BASE_URL`. Die Werte niemals in die Android-App schreiben.
8. Cloud Functions deployen: `firebase deploy --only functions`.
9. Ein erstes Konto für den Admin erstellen. Dessen UID muss einmalig durch einen vertrauenswürdigen, lokalen Admin-Bootstrap mit Custom Claim `admin: true` versehen werden. Dies darf nicht durch die App selbst möglich sein. Die hier enthaltene Funktion `bootstrapSingleAdmin` ist bewusst nicht als öffentliche Callable Function exponiert; vor Livebetrieb sollte sie als einmaliges lokales Admin-Skript ausgeführt und danach entfernt werden.
10. Einladung annehmen, Konten serverseitig gegen einen gültigen, nicht abgelaufenen Einladungstoken prüfen und erst dann einen aktiven Mitgliedsdatensatz anlegen.

## Sicherheitsmodell
- Admin-Rolle ist ein Firebase Custom Claim, nicht ein Wert, den die App setzen kann.
- Firestore-Regeln blockieren direkte Änderungen an Mitgliedsrollen und Einladungen.
- Nur aktive Mitglieder dürfen Termine und Chat lesen.
- Nur Admin darf Termine verwalten.
- Einladungsannahme muss serverseitig Token-Hash, E-Mail-Übereinstimmung, Ablaufzeit und Status prüfen und den Token danach als verbraucht markieren.

## Noch nicht fertig / vor Produktivbetrieb erforderlich
- Firebase SDK in die Android-App integrieren (Login/Logout, Auth-Status, Firestore-Repositories und Echtzeit-Listener)
- Einladungsannahme-Webseite und sichere serverseitige Token-Einlösung ergänzen
- Einmaliges, abgesichertes Admin-Bootstrap-Skript lokal ausführen und anschließend entfernen
- Push-Mitteilungen (FCM) konfigurieren
- Regeln und Funktionen mit Emulator Suite testen; Datenschutz/Impressum und Backup-Aufbewahrung festlegen

**Wichtig:** Das Paket enthält keine Firebase-Projekt-ID, keine `google-services.json`, keine SMTP-Zugangsdaten und keine echten Konten. Diese projektbezogenen Werte können nicht automatisch erfunden oder in deinem Namen angelegt werden.


## Bereits erledigt (27.10.2026)
- Die vom Nutzer bereitgestellte `google-services.json` wurde unter `app/google-services.json` abgelegt.
- Projekt-ID: `ksm-motorsport`; Android-Paketname: `de.ksmmotorsport.app`.
- Das Google Services Gradle Plugin und Firebase SDK-Abhängigkeiten sind im Android-Projekt eingetragen.

## Nächste Schritte in Firebase Console
1. Unter **Authentication → Sign-in method** E-Mail/Passwort aktivieren.
2. Unter **Firestore Database** eine Datenbank erstellen. Die mitgelieferten Sicherheitsregeln vor dem Veröffentlichen prüfen und deployen.
3. E-Mail-Einladungen nur über die vorbereitete serverseitige Cloud Function ausgeben; nicht durch eine offene öffentliche Registrierung.
4. Das einzige Admin-Konto serverseitig einrichten, danach Functions und Firestore-Regeln mit Firebase CLI bereitstellen.
5. App in Android Studio synchronisieren und bauen.

Hinweis: Die Konfiguration ist eingebunden, aber Backend-Ressourcen werden dadurch nicht automatisch erstellt oder veröffentlicht. Live-Chat, Einladungen und Push-Benachrichtigungen sind erst nach den oben genannten Schritten aktiv.
