package de.ksmmotorsport.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PersonAddAlt1
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF101012)
private val Panel = Color(0xFF1C1C20)
private val Red = Color(0xFFF32632)
private val White = Color(0xFFF6F6F6)
private val Muted = Color(0xFFB8B8BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KsmApp() }
    }
}

data class RaceEvent(val title: String, val date: String, val place: String, val detail: String, var going: Boolean = false)
data class ChatMessage(val sender: String, val text: String, val mine: Boolean = false)

@Composable
fun KsmApp() {
    var page by remember { mutableStateOf("Start") }
    var isAdmin by remember { mutableStateOf(true) } // Demo preview only; production role comes from secure backend.
    var showInvite by remember { mutableStateOf(false) }
    var showEvent by remember { mutableStateOf(false) }
    var inviteEmail by remember { mutableStateOf("") }
    var eventTitle by remember { mutableStateOf("") }
    var eventDate by remember { mutableStateOf("") }
    var eventPlace by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    val events = remember { mutableStateListOf(
        RaceEvent("Deutsche Meisterschaft", "16. Mai 2027", "Noch einzutragen", "Rennwochenende · Details folgen"),
        RaceEvent("Teamtraining", "30. Mai 2027", "Trainingsgelände", "Fahrzeugcheck und Vorbereitung")
    ) }
    val messages = remember { mutableStateListOf(
        ChatMessage("Teamleitung", "Willkommen im internen KSM-Teamchat!"),
        ChatMessage("Mechanik", "Bitte vor dem nächsten Rennen Werkzeug prüfen."),
        ChatMessage("Peter Menzel", "Alles klar, ich kümmere mich darum.", true)
    ) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel, onSurface = White)) {
        Scaffold(
            containerColor = Black,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = White) {
                    NavItem("Start", page, { page = it }, Icons.Default.Home)
                    NavItem("Termine", page, { page = it }, Icons.Default.CalendarMonth)
                    NavItem("Chat", page, { page = it }, Icons.Default.ChatBubbleOutline)
                    NavItem("Team", page, { page = it }, Icons.Default.People)
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Black)) {
                Header(onInvite = { showInvite = true }, isAdmin = isAdmin)
                when (page) {
                    "Start" -> HomePage(events, onGoEvents = { page = "Termine" }, onGoChat = { page = "Chat" })
                    "Termine" -> EventsPage(events, isAdmin, onAdd = { showEvent = true })
                    "Chat" -> ChatPage(messages, draft, { draft = it }, {
                        if (draft.isNotBlank()) { messages.add(ChatMessage("Du", draft.trim(), true)); draft = "" }
                    })
                    else -> TeamPage(isAdmin, onInvite = { showInvite = true })
                }
            }
        }

        if (showInvite) {
            AlertDialog(
                onDismissRequest = { showInvite = false },
                containerColor = Panel,
                title = { Text("Teammitglied einladen", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Die echte E-Mail-Einladung wird nach Anbindung des sicheren Backend-Dienstes versendet.", color = Muted, fontSize = 13.sp)
                        DarkInput(inviteEmail, { inviteEmail = it }, "E-Mail-Adresse")
                    }
                },
                confirmButton = { TextButton(onClick = { showInvite = false; inviteEmail = "" }) { Text("Schließen", color = Red) } },
                dismissButton = { TextButton(onClick = { showInvite = false }) { Text("Abbrechen", color = Muted) } }
            )
        }
        if (showEvent) {
            AlertDialog(
                onDismissRequest = { showEvent = false },
                containerColor = Panel,
                title = { Text("Neuen Termin anlegen", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        DarkInput(eventTitle, { eventTitle = it }, "Veranstaltung")
                        DarkInput(eventDate, { eventDate = it }, "Datum, z. B. 12. Juni 2027")
                        DarkInput(eventPlace, { eventPlace = it }, "Ort")
                    }
                },
                confirmButton = { TextButton(onClick = {
                    if (eventTitle.isNotBlank() && eventDate.isNotBlank()) events.add(0, RaceEvent(eventTitle.trim(), eventDate.trim(), eventPlace.ifBlank { "Ort folgt" }, "Von der Teamleitung erstellt"))
                    eventTitle = ""; eventDate = ""; eventPlace = ""; showEvent = false
                }) { Text("Termin speichern", color = Red) } },
                dismissButton = { TextButton(onClick = { showEvent = false }) { Text("Abbrechen", color = Muted) } }
            )
        }
    }
}

@Composable
private fun NavItem(label: String, current: String, onSelect: (String) -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    NavigationBarItem(selected = current == label, onClick = { onSelect(label) }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 11.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = Red, indicatorColor = Color(0xFF3A171B), unselectedIconColor = Muted, unselectedTextColor = Muted))
}

@Composable
fun Header(onInvite: () -> Unit, isAdmin: Boolean) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF080809)).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.ksm_logo),
            contentDescription = "KSM Motorsport Logo",
            modifier = Modifier.width(154.dp).height(52.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text("INTERNES TEAM", color = Red, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp)
            if (isAdmin) Text("ADMIN-MODUS", color = Muted, fontSize = 9.sp)
        }
        Spacer(Modifier.width(4.dp))
        IconButton(onClick = onInvite) { Icon(Icons.Default.PersonAddAlt1, "Einladen", tint = Red) }
    }
    Box(Modifier.fillMaxWidth().height(3.dp).background(Red))
}

@Composable
fun HomePage(events: List<RaceEvent>, onGoEvents: () -> Unit, onGoChat: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(150.dp).background(Panel, RoundedCornerShape(16.dp)).padding(18.dp)) {
                Column(Modifier.align(Alignment.BottomStart)) {
                    Text("RACING IS A TEAM SPORT", color = Red, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("GEMEINSAM.\nVOLLGAS.", color = White, fontSize = 27.sp, lineHeight = 29.sp, fontWeight = FontWeight.Black)
                }
                Icon(Icons.Default.DirectionsCar, null, tint = Color(0xFF5B2025), modifier = Modifier.align(Alignment.TopEnd).size(68.dp))
            }
        }
        item { SectionTitle("NÄCHSTER TERMIN", "Alle Termine", onGoEvents) }
        if (events.isNotEmpty()) item { EventCard(events.first(), onToggle = {}) }
        item { SectionTitle("TEAM-KOMMUNIKATION", "Zum Chat", onGoChat) }
        item {
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onGoChat() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ChatBubbleOutline, null, tint = Red, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text("Interner Team-Chat", color = White, fontWeight = FontWeight.Bold); Text("Absprachen für das nächste Rennen", color = Muted, fontSize = 12.sp) }
                Text("ÖFFNEN  ›", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        item { Text("PROTOTYP · DEMODATEN", color = Color(0xFF77777D), fontSize = 10.sp, letterSpacing = 1.2.sp, modifier = Modifier.padding(top = 8.dp)) }
    }
}

@Composable
fun EventsPage(events: List<RaceEvent>, isAdmin: Boolean, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("RENNKALENDER", color = Red, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp); Text("Termine & Veranstaltungen", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
            if (isAdmin) Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Red), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) { Text("+ Termin", color = White) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(events) { event -> EventCard(event, onToggle = { event.going = !event.going }) }
        }
    }
}

@Composable
fun EventCard(event: RaceEvent, onToggle: () -> Unit) {
    var going by remember(event.title, event.date) { mutableStateOf(event.going) }
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(15.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Box(Modifier.width(5.dp).height(58.dp).background(Red, RoundedCornerShape(3.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(event.date.uppercase(), color = Red, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                Text(event.title, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("📍 ${event.place}", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(event.detail, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { going = !going; onToggle() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = if (going) Red else White), border = androidx.compose.foundation.BorderStroke(1.dp, if (going) Red else Color.DarkGray)) {
            Text(if (going) "✓ Teilnahme vorgemerkt" else "Teilnahme bestätigen")
        }
    }
}

@Composable
fun ChatPage(messages: List<ChatMessage>, draft: String, onDraft: (String) -> Unit, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Column(Modifier.padding(top = 18.dp, bottom = 12.dp)) { Text("KSM KOMMUNIKATION", color = Red, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp); Text("Team-Chat", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Nur für eingeladene Mitglieder", color = Muted, fontSize = 12.sp) }
        LazyColumn(Modifier.weight(1f), reverseLayout = false, contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                    Column(Modifier.widthIn(max = 290.dp).background(if (msg.mine) Color(0xFF492025) else Panel, RoundedCornerShape(12.dp)).padding(12.dp)) {
                        Text(msg.sender.uppercase(), color = if (msg.mine) Red else Muted, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(4.dp)); Text(msg.text, color = White, fontSize = 14.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp).background(Panel, RoundedCornerShape(28.dp)).padding(start = 16.dp, end = 5.dp, top = 5.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = draft, onValueChange = onDraft, modifier = Modifier.weight(1f).padding(vertical = 10.dp), textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp), cursorBrush = SolidColor(Red), decorationBox = { inner -> if (draft.isEmpty()) Text("Nachricht schreiben …", color = Muted, fontSize = 14.sp); inner() })
            IconButton(onClick = onSend) { Icon(Icons.Default.Send, "Senden", tint = Red) }
        }
        Text("DEMO-CHAT · Noch nicht mit anderen Geräten synchronisiert", color = Color(0xFF77777D), fontSize = 9.sp, modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
fun TeamPage(isAdmin: Boolean, onInvite: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("DIE CREW", color = Red, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
        Text("Teamverwaltung", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Color(0xFF3A171B), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("PM", color = Red, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Peter Menzel", color = White, fontWeight = FontWeight.Bold); Text("KSM Motorsport", color = Muted, fontSize = 12.sp) }
            Text("ADMIN", color = Red, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.People, null, tint = Red, modifier = Modifier.size(34.dp)); Spacer(Modifier.width(12.dp)); Column { Text("Mitgliederbereich", color = White, fontWeight = FontWeight.Bold); Text("Einladungen werden vom Admin verwaltet", color = Muted, fontSize = 12.sp) }
        }
        if (isAdmin) { Spacer(Modifier.height(16.dp)); Button(onClick = onInvite, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Icon(Icons.Default.PersonAddAlt1, null); Spacer(Modifier.width(8.dp)); Text("Per E-Mail einladen") } }
        Spacer(Modifier.height(18.dp))
        Text("SICHERHEIT", color = Red, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        Text("In dieser Vorschau ist der Admin-Modus nur simuliert. Vor dem Livebetrieb werden Admin-Rechte serverseitig festgelegt, Einladungen per E-Mail geprüft und Konten geschützt gespeichert.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
fun SectionTitle(title: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
        Text(action.uppercase() + "  ›", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onClick() })
    }
}

@Composable
fun DarkInput(value: String, onValue: (String) -> Unit, placeholder: String) {
    OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(), placeholder = { Text(placeholder, color = Muted) }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Red, unfocusedBorderColor = Color.DarkGray, cursorColor = Red, focusedContainerColor = Black, unfocusedContainerColor = Black))
}
