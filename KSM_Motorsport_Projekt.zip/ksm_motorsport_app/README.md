# KSM Motorsport – Android-Prototyp

Native Android-App auf Kotlin + Jetpack Compose, gestaltet nach der KSM-Motorsport-Vorlage (Schwarz/Rot/Weiß). Das originale KSM-Motorsport-Logo aus dem oberen linken Bereich der bereitgestellten Vorlage wird im App-Kopf verwendet.

## Enthaltene Demo-Funktionen
- Originales KSM-Motorsport-Logo aus der Designvorlage im App-Kopf
- Startseite mit Teambranding und nächstem Termin
- Rennkalender mit Beispielterminen
- Termine lokal hinzufügen (Admin-Demo)
- Teilnahme im Prototyp vormerken
- Chat-Oberfläche mit lokalem Demo-Chat und Nachrichten-Eingabe
- Team-Ansicht und Dialog für E-Mail-Einladung
- Navigation zwischen Start, Termine, Chat und Team

## Öffnen
1. ZIP entpacken.
2. Ordner `ksm_motorsport_app` in Android Studio öffnen.
3. Gradle-Synchronisierung abwarten.
4. Auf einem Android-Emulator oder einem verbundenen Android-Handy starten.

Voraussetzung: Android Studio mit Android SDK 35 und JDK 17.

## Wichtiger Hinweis zum Prototyp
Dies ist ein UI-/Funktionsprototyp mit lokalen Demodaten, noch kein einsatzbereites Team-System. Einladungen werden nicht wirklich versendet und Chatnachrichten werden nicht auf andere Geräte synchronisiert. Der Admin-Modus ist in der Vorschau simuliert und darf nicht als Sicherheitsmechanismus verwendet werden.

## Für den Livebetrieb erforderlich
- Authentifizierung mit E-Mail-Einladung und Verifikation
- Serverseitig abgesicherte Rolle `admin` mit genau einem Admin-Konto
- Datenbank für Mitglieder, Termine, Teilnahme und Nachrichten
- Echtzeit-Chat und Push-Mitteilungen
- Regeln, die sämtliche Datenzugriffe auf eingeladene Mitglieder beschränken

Die vorhandene Struktur ist als Ausgangspunkt für diese Integration gedacht.
