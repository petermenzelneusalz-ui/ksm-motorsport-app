// EXAMPLE ONLY: run locally from a trusted machine, never from the Android app.
// Requires GOOGLE_APPLICATION_CREDENTIALS to point to a restricted service-account
// key stored securely outside the project. Delete the key after the one-time setup.
const admin = require('firebase-admin');
admin.initializeApp();

async function main() {
  const email = process.argv[2];
  if (!email) throw new Error('Usage: node bootstrap-admin.example.js admin@example.com');
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, { ...(user.customClaims || {}), admin: true });
  await admin.firestore().collection('members').doc(user.uid).set({
    uid: user.uid,
    email: user.email,
    displayName: user.displayName || 'KSM Admin',
    active: true,
    role: 'admin',
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });
  console.log(`Admin eingerichtet: ${email} (${user.uid}). Dieses Skript danach entfernen.`);
}
main().catch(err => { console.error(err); process.exit(1); });
