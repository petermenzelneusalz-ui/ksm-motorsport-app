const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');

admin.initializeApp();
const db = admin.firestore();
const smtpHost = defineSecret('SMTP_HOST');
const smtpPort = defineSecret('SMTP_PORT');
const smtpUser = defineSecret('SMTP_USER');
const smtpPassword = defineSecret('SMTP_PASSWORD');
const inviteBaseUrl = defineSecret('INVITE_BASE_URL');

// Only a user with the server-assigned admin custom claim may create invitations.
exports.createTeamInvitation = onCall(
  { secrets: [smtpHost, smtpPort, smtpUser, smtpPassword, inviteBaseUrl] },
  async (request) => {
    if (!request.auth || request.auth.token.admin !== true) {
      throw new HttpsError('permission-denied', 'Nur der Admin darf Einladungen versenden.');
    }
    const email = String(request.data?.email || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      throw new HttpsError('invalid-argument', 'Bitte eine gültige E-Mail-Adresse eingeben.');
    }

    const existing = await db.collection('members').where('email', '==', email).limit(1).get();
    if (!existing.empty) throw new HttpsError('already-exists', 'Diese Adresse ist bereits Teammitglied.');

    const token = require('crypto').randomBytes(32).toString('hex');
    const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');
    const expiresAt = admin.firestore.Timestamp.fromMillis(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await db.collection('invitations').doc(tokenHash).set({
      email, invitedBy: request.auth.uid, status: 'pending', expiresAt,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });

    const port = Number(smtpPort.value() || 587);
    const transporter = nodemailer.createTransport({
      host: smtpHost.value(), port, secure: port === 465,
      auth: { user: smtpUser.value(), pass: smtpPassword.value() }
    });
    const link = `${inviteBaseUrl.value().replace(/\/$/, '')}/accept-invite?token=${token}`;
    await transporter.sendMail({
      from: smtpUser.value(), to: email,
      subject: 'Einladung zu KSM Motorsport',
      text: `Du wurdest zum internen Team von KSM Motorsport eingeladen. Der Link ist 7 Tage gültig:\n\n${link}\n\nWenn du diese Einladung nicht erwartest, ignoriere diese E-Mail.`,
      html: `<p>Du wurdest zum internen Team von <b>KSM Motorsport</b> eingeladen.</p><p><a href="${link}">Einladung annehmen</a></p><p>Der Link ist 7 Tage gültig.</p>`
    });
    return { ok: true };
  }
);

